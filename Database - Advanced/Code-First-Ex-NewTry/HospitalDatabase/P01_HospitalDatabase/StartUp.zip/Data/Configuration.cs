﻿namespace P01_HospitalDatabase.Data
{
    public static class Configuration
    {
        public const string ConnectionString =
            "Server=DESKTOP-J3MO4KV\\SQLEXPRESS;Database=Hospital;Integrated Security=True";
    }
}