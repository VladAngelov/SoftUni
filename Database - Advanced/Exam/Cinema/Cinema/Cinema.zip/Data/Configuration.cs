﻿namespace Cinema.Data
{
   public static class Configuration
    {
        public static string ConnectionString = @"Server=DESKTOP-J3MO4KV\SQLEXPRESS;Database=Cinema;Trusted_Connection=True";
    }
}