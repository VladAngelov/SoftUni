﻿namespace Cinema.DataProcessor
{
    using System;
    using System.Linq;

    using Newtonsoft.Json;

    using Data;
    using Data.Models;

    public class Serializer
    {
        public static string ExportTopMovies(CinemaContext context, int rating)
        {
            var moviesToExport =
                context
                    .Projections
                    .Where(p => p.Movie.Rating >= rating &&
                                p.Movie.Projections
                                    .Any(z => z.Tickets.Count > 0))
                    .Select(m => new
                    {
                        Name = m.Movie.Title,
                        Rating = $"{m.Movie.Rating:f2}",
                        TotalIncomes = m.Tickets
                            .Select(t => t.Price)
                            .Sum(),
                        Customers = context.Tickets.Select(c => new Customer
                        {
                            FirstName = c.Customer.FirstName,
                            LastName = c.Customer.LastName,
                            Balance = c.Customer.Balance
                        })
                            .OrderByDescending(bal => bal.Balance)
                            .ThenBy(f => f.FirstName)
                            .ThenBy(l => l.LastName)
                            .ToArray()
                    })
                    .OrderByDescending(r => r.Rating)
                    .ThenByDescending(total => total.TotalIncomes)
                    .Take(10)
                    .ToArray();

            var json = JsonConvert.SerializeObject(moviesToExport, Formatting.Indented);

            return json;
        }

        public static string ExportTopCustomers(CinemaContext context, int age)
        {
            throw new NotImplementedException();
        }
    }
}